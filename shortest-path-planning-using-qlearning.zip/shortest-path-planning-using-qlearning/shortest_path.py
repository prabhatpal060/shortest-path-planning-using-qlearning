
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.animation as animation
import random

def read_matrix_from_excel(file_path, sheet_name):
    try:
        df = pd.read_excel(file_path, sheet_name=sheet_name, header=None)
        matrix = df.values
        print("Matrix Loaded:")
        print(matrix)
        return matrix
    except Exception as e:
        print(f"Error reading Excel file: {e}")
        return None

def visualize_matrix(matrix):
    cmap = {
        0: (0, 0, 0),
        1: (1, 1, 1),
        2: (0, 1, 0),
        3: (1, 0, 0),
        4: (1, 1, 0)
    }
    color_matrix = np.zeros((matrix.shape[0], matrix.shape[1], 3))
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            color_matrix[i, j] = cmap.get(matrix[i, j], (0, 0, 0))
    plt.imshow(color_matrix, interpolation='nearest')
    plt.axis('off')
    plt.show()

def animate_path(matrix, path, delay=300):
    rows, cols = matrix.shape
    fig, ax = plt.subplots()

    def draw_static_grid(current_idx):
        ax.clear()
        ax.set_xticks(range(cols + 1))
        ax.set_yticks(range(rows + 1))
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        ax.grid(True)

        for r in range(rows):
            for c in range(cols):
                val = matrix[r, c]
                color = 'white'
                if val == 0:
                    color = 'black'
                elif val == 2:
                    color = 'green'
                elif val == 3:
                    color = 'red'
                elif val == 4:
                    color = 'yellow'

                display_r = rows - 1 - r

                if (r, c) in path[:current_idx] and matrix[r, c] == 1:
                    color = 'yellow'

                ax.add_patch(patches.Rectangle((c, display_r), 1, 1, facecolor=color))

    def update(frame):
        draw_static_grid(frame)
        r, c = path[frame]
        display_r = rows - 1 - r
        circle = patches.Circle((c + 0.5, display_r + 0.5), 0.3, color='orange', ec='white', lw=2)
        ax.add_patch(circle)
        ax.set_title(f"Step: {frame}, Reward: {1.0 if frame == len(path)-1 else -0.1:.1f}")

    ani = animation.FuncAnimation(fig, update, frames=len(path), interval=delay, repeat=False)
    plt.show()

def q_learning(matrix, start, goal, episodes=1000, alpha=0.1, gamma=0.9, epsilon=0.1):
    rows, cols = matrix.shape
    actions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    temp_matrix = matrix.copy()
    temp_matrix[temp_matrix == 2] = 0
    temp_matrix[goal] = 2
    q_table = np.zeros((rows, cols, len(actions)))

    def is_valid_move(r, c):
        return 0 <= r < rows and 0 <= c < cols and temp_matrix[r, c] != 0

    for episode in range(episodes):
        state = start
        while state != goal:
            r, c = state
            if random.uniform(0, 1) < epsilon:
                action_idx = random.randint(0, len(actions) - 1)
            else:
                action_idx = np.argmax(q_table[r, c])

            dr, dc = actions[action_idx]
            new_r, new_c = r + dr, c + dc

            if is_valid_move(new_r, new_c):
                reward = 1 if (new_r, new_c) == goal else -0.1
                old_value = q_table[r, c, action_idx]
                next_max = np.max(q_table[new_r, new_c])
                q_table[r, c, action_idx] = old_value + alpha * (reward + gamma * next_max - old_value)
                state = (new_r, new_c)
            else:
                q_table[r, c, action_idx] -= alpha * 0.5

    return q_table

def extract_policy(matrix, q_table, start, goal):
    state = start
    path = [state]
    actions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    while state != goal:
        r, c = state
        action_idx = np.argmax(q_table[r, c])
        dr, dc = actions[action_idx]
        new_r, new_c = r + dr, c + dc

        if not (0 <= new_r < matrix.shape[0] and 
                0 <= new_c < matrix.shape[1] and 
                matrix[new_r, new_c] != 0 and 
                (new_r, new_c) not in path):
            return []

        state = (new_r, new_c)
        path.append(state)

    return path if path[-1] == goal else []

def main():
    file_path = input("Enter the path to the Excel file: ")
    sheet_name = input("Enter the sheet name for the matrix: ")
    matrix = read_matrix_from_excel(file_path, sheet_name)
    if matrix is None:
        return

    start_positions = np.argwhere(matrix == 3)
    goal_positions = np.argwhere(matrix == 2)

    if start_positions.size == 0:
        print("Not locating the Starting Point")
        return
    if goal_positions.size == 0:
        print("Not locating the Goal Points")
        return

    start = tuple(map(int, start_positions[0]))
    goals = [tuple(map(int, goal)) for goal in goal_positions]

    print(f"Start Point: {start}, Goal Points: {goals}")

    paths = {}
    for goal in goals:
        q_table = q_learning(matrix, start, goal)
        optimal_path = extract_policy(matrix, q_table, start, goal)

        if optimal_path:
            paths[goal] = optimal_path
        else:
            print(f"No valid path found for Goal {goal}")

    for goal, path in paths.items():
        print(f"Animating path to Goal {goal}")
        animate_path(matrix, path)

if __name__ == "__main__":
    main()



#***************************************************************************************
#***************************************************************************************
#***************************************************************************************
    # Command to run the code:-
    # C:\Users\prabh\Desktop\FINAL YEAR PROJECT\Final\Matrix.xlsx
    # Sheet
#***************************************************************************************
#***************************************************************************************
#***************************************************************************************